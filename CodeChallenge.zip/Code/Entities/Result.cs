﻿using System.Collections.Generic;

namespace RebellionCodeChallenge.Entities {
   public class Result {
      public string ProductName { get; set; }
      public List<Listing> Listings { get; set; }
   }
}
