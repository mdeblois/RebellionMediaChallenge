﻿
namespace RebellionCodeChallenge {
   public enum EStatusCode {
      Success = 0,
      Error = 1,
      ErrorReadingFile = 2,
      ErrorWritingFile = 3
   }
}
